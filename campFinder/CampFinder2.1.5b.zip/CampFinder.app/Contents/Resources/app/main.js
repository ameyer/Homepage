//electron-packager . --overwrite --arch=x64 --platform=darwin --prune=true --out=release-builds --icon=assets/icons/mac/icon.icns




const electron = require('electron')
const {app, net, BrowserWindow} = require('electron');
const ipc = require('electron').ipcMain;

require('mootools');
require('mootools-more');
require('electron-debug')();

//var parkinfo = require('./js/campsites.js');
//console.log(parkinfo);

let mainWindow;

var parkinfo = '';
var searchPageIsReady = false;

//var searchCommandTab;
var campSearches = [];
var registerTabs = [];
var unitDayAggregates = [];
var maxWorkingAtATime = 2;

ipc.on('tabMessage', (event, info)=> {
	var action = info.name;
	var data = info.message;
	
	if(action != 'unitDayInformation'){
		console.log('tabMessage', action);
	}
	
	var campSearchObj = false;
	var registerTabObj = false;
	
	for (var registerTab of registerTabs) {
		if(event.sender.webContents == registerTab.tab.webContents){
			registerTabObj = registerTab;
		}
	}
	
	for (var campSearch of campSearches) {
		if(campSearch.tab && event.sender){
			if(campSearch.tab.webContents == event.sender.webContents){
				campSearchObj = campSearch;
			}
		}
	}
	
	switch (action) {
		
		case "unitDayInformation":
			if(campSearchObj){
				if(campSearchObj.park){
					if(campSearchObj.park.place_id){
						
						if(typeof data =='object' && data){
							data.place_id = campSearchObj.park.place_id;
							campSearchObj.addDay(data);
						}else{
							console.error('data object looks bad', campSearchObj, data);
						}
						
					}else{
						console.error('no campSearchObj.park', campSearchObj);
					}
				}else{
					console.error('no campSearchObj.park', campSearchObj);
				}
			}
			
			break;
		case "tellMeToLoadSite":
			//for testing purposes
			
			
			if(campSearchObj){
				//console.log('I found this tab!');
				campSearchObj.goToSite(data.place_id, data.facilityid);
			}else if(registerTabObj){
				console.log("tellMeToLoadSite 1", data);
				registerTabObj.goToSite(data.place_id, data.facilityid);
			}else {
				console.log("tellMeToLoadSite 2", data);
				
				for (var park of parkinfo) {
					if(data.place_id == park.place_id){
						
						for(var facility of park.facilities){
							if(facility.id == data.facilityid){
								var date = new Date().parse("03/12/2018");
								
								var tab = new RegisterTab(null, park, facility, data.date, event.sender.webContents);
								registerTabs.push(tab);
								tab.goToSite(park.place_id, facility.id);
							}
						}
					}
				}
			}
						
			break;
		case "searchUpdate":
			if(campSearchObj){
				campSearchObj.searchUpdate(data.daysLeft);
			}
			
			break;
		
		case "whereShouldIBe":
			
			if(campSearchObj){
				campSearchObj.reportWhereWeShouldBe();
			}else if(registerTabObj){
				registerTabObj.reportWhereWeShouldBe();
			}
			
			break;
			
			
		case "inTheWrongPlace":
			console.log('inTheWrongPlace', data);
			break;	
		
		
		case "inTheRightPlace":
			//we are in the right place, now what?
			if(campSearchObj){
				campSearchObj.searchDateRange();
			}else if(registerTabObj){
				registerTabObj.setTheDate();
			}
			break;
		case "tabHasAnError":
			if(campSearchObj){
				console.warn("tab has an error", data.error, campSearchObj.numberOfErrors);
				campSearchObj.hasAnError();
			}
			
			break;
		case "searchComplete":
		//tab is done with it's search, we can close it
			if(campSearchObj){
				campSearchObj.searchComplete();
			}else{
				console.log("can't find this searchObj");
			}
			
			var working = 0;
			for(var campSearch of campSearches){
				if(!campSearch.started){
					campSearch.start();
					//mainWindow.focus();
					working ++;
				}else if(campSearch.started && !campSearch.completed){
					//working but not done;
					working ++;
				}
				
				if(working >= maxWorkingAtATime) break;
			}
			
			if(working == 0){
				console.timeEnd("searchTimer");
			}
			
		break;
		default:
		  console.log(action, data);
	}
	
});

ipc.on('newRegisterTab', (event, data)=> {
	
	for (var park of parkinfo) {
		if(data.place_id == park.place_id){
			
			for(var facility of park.facilities){
				if(facility.id == data.facilityid){
					var tab = new RegisterTab(park, facility, data.date);
					registerTabs.push(tab);
				}
			}
		}
	}
	
});

ipc.on('searchCommandTabReadyForSiteInfo', (event, data)=> {
	searchPageIsReady = true;
	sendParkData();
})

function sendParkData(){
	console.log('sendParkData', parkinfo);
	if(parkinfo != ''){
		mainWindow.send("parkInfo", {sites: parkinfo});
	}
}


ipc.on('startSearching', (event, data)=> {	
	campSearches = []; //empty it - trying to prevent repeat tabs from opening on second search
	
	//data.sites is an array sent over from the search page with a list of all the sites (just their names) we should search
	//Find the park object that matches the names sent over and use it to make a new "CampSearch" for each one selected
	
	var startDate = new Date().parse(data.startDate);
	var endDate = new Date().parse(data.startDate).increment('day', data.numberOfDays);
	
	for (var siteName of data.sites) {
		for (var park of parkinfo) {
			if(siteName == park.name){
				for (var facility of park.facilities) {
					//campSearches.push(new CampSearch(searchCommandTab.browserWindow, park, facility, startDate, endDate));
					campSearches.push(new CampSearch(null, park, facility, startDate, endDate));
				}
			}
		}
	}
	
	console.time("searchTimer");
	
	var working = 0;
	for(var campSearch of campSearches){
		if(!campSearch.started){
			campSearch.start();
			mainWindow.focus();
			working ++;
		}else if(campSearch.started && !campSearch.completed){
			//working but not done;
			working ++;
		}
		
		if(working >= maxWorkingAtATime) break;
	}
});


function createWindow () {
  mainWindow = new BrowserWindow({
  	width: 1024,
  	height: 768,
  	minHeight: 400,
  	minWidth: 600,
  	fullscreen: false
  });
  //mainWindow.loadFile('./searchPage/search.html');
  
  mainWindow.loadFile('./searchPage/search.html');
  
  //mainWindow.loadURL('http://adam-meyer.com/campFinder/searchPage/search.html?'+ new Date().getTime());

  mainWindow.on('closed', function () {
    mainWindow = null;
	app.quit();
  })
  
	
	
	const request = net.request('http://adam-meyer.com/campFinder/campsitesBeta_ULTRA.js?'+ new Date().getTime())
	request.on('response', (response) => {
		var data = '';
		
		response.on('data', (chunk) => {
			data += chunk;
		})
		
		response.on('end', () => {
		  parkinfo = JSON.parse(data);
		  if(searchPageIsReady){
		  	sendParkData();
		  }
		})
	})
	request.end()
	
	
  
}

app.on('ready', createWindow)

app.on('window-all-closed', function () {
	app.quit()
})


class CampSearch{
	
	constructor(parentWindow, park, facility, startDate, endDate, tab){
		this.park = park;
		this.facility = facility;
		this.ready = false;
		this.startDate = startDate;
		this.endDate = endDate;
		this.numberOfErrors = 0;
		this.unitDayAggregates = [];
		this.tab = tab;
		this.started = false;
		this.completed = false;
		//this.parentWindow = parentWindow;
	}
	
	start(){		
		this.started = true;
		
		this.tab = new BrowserWindow({
			width: 1,
			height: 1,
			x: 0,
			y: 0,
			transparent: true,
			frame: false,
			show: false,
			webPreferences: {
				preload: __dirname+'/js/pageControl.js',
				nodeIntegration: false
			}
		});
		
		
		this.tab.on('closed', function () {
		  removeObjectFromArray(campSearches, this);
		}.bind(this))
		
		this.tab.webContents.on('did-finish-load', function() {
		 	this.tab.webContents.insertCSS('html,body{ overflow: hidden !important;}');
		}.bind(this));
		
		this.tab.loadURL("https://www.reservecalifornia.com/CaliforniaWebHome/Facilities/AdvanceSearch.aspx");
		this.tab.showInactive();
		
		mainWindow.send("searchStarted", {
			place_id: this.park.place_id, 
			facilityid: this.facility.id
		});
	}
	
	addDay(dayData){
		
		var proper_unitDayAggregate = false;
		
		for (var unitDayAggregate of this.unitDayAggregates) {
			if(unitDayAggregate.place_id == dayData.place_id && unitDayAggregate.facility_id == dayData.facility_id && unitDayAggregate.unit_id == dayData.unit_id){
				proper_unitDayAggregate = unitDayAggregate;
				break;
			}
		}
		
		if(proper_unitDayAggregate){
			proper_unitDayAggregate.addDay(dayData);
		}else{
			this.unitDayAggregates.push(new UnitDayAggregate(dayData, this.startDate, this.endDate));
		}
	}
	
	searchUpdate(daysLeft){
		var totalDaysNeeded = this.startDate.diff(this.endDate);
		var totalSectionsNeeded = (totalDaysNeeded / 21) +2;
		var sectionsComplete;
		
		if(daysLeft == -1){
			sectionsComplete = 1;
		}else if(daysLeft == -2){
			sectionsComplete = 0;
		}else{
			var daysSearched = totalDaysNeeded - daysLeft;
			sectionsComplete = (daysSearched/21) +2;
		}
		
		var percentComplete = sectionsComplete / totalSectionsNeeded;
		console.log('percent complete', this.facility.name, percentComplete, daysLeft);
		
		mainWindow.send("searchUpdate", {
			percent: Math.round(percentComplete * 100),
			place_id: this.park.place_id, 
			facilityid: this.facility.id
		});
	
	}
	
	message(message, data){
		//send message to the tab associated with this object
		console.log("##"+message);
		this.tab.webContents.send(message, data);
	}
	
	reportWhereWeShouldBe(){
		console.log(this.park.site_name, this.facility.name);
		this.message("youShouldBeHere", {
			place_id: this.park.place_id, 
			facilityid: this.facility.id, 
			parkName: this.park.site_name, 
			facilityName: this.facility.name, 
			startDate: this.startDate, 
		});
	}
	
	goToSite(place_id, facilityid){
		this.message("goToSite", {place_id: place_id, facilityid: facilityid});
	}
	
	searchDateRange(){				
		//send a message to the tab - scrub it for openings in this date range
		this.message("searchDateRange", {startDate: this.startDate.format('%x'), endDate: this.endDate.format('%x')});
	}
	
	searchComplete(){
		this.completed = true;
		
		mainWindow.send("searchComplete", {
			place_id: this.park.place_id, 
			facilityid: this.facility.id
		});
		
		this.processUnitDayAggregates();
		this.closeTab(); //disable for testing
	}
	hasAnError(){
		this.startOver();
		console.warn("ANOTHER ERROR: "+ this.numberOfErrors);
		this.numberOfErrors ++;
	}
	
	startOver(){
		this.tab.loadURL("https://www.reservecalifornia.com");
	}
	
	closeTab(){
		this.tab.close();
		this.tab = false;
	}
	
	processUnitDayAggregates() {  
		var daysFound = 0;
		var numberOfDays = this.startDate.diff(this.endDate);
		
		for (var i = 0; i < numberOfDays; i++) {
			if(daysFound >= numberOfDays){
			  break;
			}else{
				var siteInfo = this.findCampsiteWithMostDaysAvailable(this.unitDayAggregates, daysFound, (numberOfDays - daysFound));
				
				var siteId = siteInfo.siteID;
				if(siteId != -1){
					daysFound += siteInfo.days;
					if(mainWindow) mainWindow.send('spotDayInformation', {place_id: this.park.place_id, startDate: this.startDate, siteInfo: siteInfo, facilityid: this.facility.id});
				
				}else{
					daysFound += 1; //skip to the next day
					if(mainWindow) mainWindow.send('spotDayInformation', {place_id: this.park.place_id, startDate: this.startDate, siteInfo: siteInfo, facilityid: this.facility.id});
				}	
			}	
		}
		console.log('done with this crap');
	}
	
	findCampsiteWithMostDaysAvailable(unitDayAggregates, startIndex, daysStillNeeded){
		var daysToStay = (startIndex + daysStillNeeded);
		var maxFound = 0;
		var siteWithMost;
		var campsiteNumber;
		
		for(var unitDayAggregate of unitDayAggregates){
			var days = unitDayAggregate.days;
			
			var daysWithAvaiability = 0;
			
			for (var dayIndex = startIndex; dayIndex < daysToStay; dayIndex++) {
				var day = days[dayIndex];
				
				if(day.is_available){
					daysWithAvaiability ++;
				}else{
					break;
				}
			}
			
			if(daysWithAvaiability > maxFound){
				siteWithMost = unitDayAggregate;
				maxFound = daysWithAvaiability
				campsiteNumber = unitDayAggregate.unit_id;
				if(maxFound >= daysToStay) break; //no need to keep looking
			}
		}
		
		return {
			siteID: (maxFound == 0)? -1: campsiteNumber,
			days: maxFound, //might be 0
			date: new Date(this.startDate).increment('day', startIndex).format('%x'),
		};
		
	}
}

function removeObjectFromArray(myArray, object){
	for (var i = myArray.length - 1; i >= 0; --i) {
	    var objectInArray = myArray[i];
		if(objectInArray == object){
			myArray.splice(i,1);
			console.log('object Removed');
			break;
		}
	}
}

class RegisterTab{
	
	constructor(park, facility, date, tab){
		this.facilityName = facility.name;
		this.parkName = park.site_name;
		this.place_id = park.place_id;
		this.facilityid = facility.id;
		this.date = new Date().parse(date);
		
		if(!tab){
			
			const {width, height} = electron.screen.getPrimaryDisplay().workAreaSize
			
			
			this.tab = new BrowserWindow({
				width: 1024,
				height: height,
				x: 0,
				y: 0,
				transparent: false,
				frame: true,
				webPreferences: {
					preload: __dirname+'/js/pageControl.js',
					nodeIntegration: false
				}
			});
			
			this.tab.loadURL("https://www.reservecalifornia.com/CaliforniaWebHome/");
			
			this.tab.on('closed', function () {
			  removeObjectFromArray(registerTabs, this);
			}.bind(this))
			
		}else{
			this.tab = tab;
		}
	}
	
	message(message, data){
		//send message to the tab associated with this object
		console.log("##"+message);
		this.tab.send(message, data);
	}
	
	setTheDate(){				
		//send a message to the tab - scrub it for openings in this date range
		this.message("setTheDate", {startDate: this.date.format('%x')});
	}
	
	reportWhereWeShouldBe(){
		
		this.message("youShouldBeHere", {
			place_id: this.place_id, 
			facilityid: this.facilityid, 
			parkName: this.parkName, 
			facilityName: this.facilityName, 
			startDate: this.date, 
		});
	}
	
	goToSite(place_id, facilityid){
		this.message("goToSite", {place_id: place_id, facilityid: facilityid});
	}
	
	searchDateRange(){				
		//send a message to the tab - scrub it for openings in this date range
		this.message("searchDateRange", {startDate: this.startDate.format('%x'), endDate: this.endDate.format('%x')});
	}
}


class UnitDayAggregate{

	constructor(dayData, startDate, endDate){
		this.days = [];
		
		this.place_id = dayData.place_id;
		this.facility_id = dayData.facility_id;
		this.unit_id = dayData.unit_id;
		this.startDate = startDate;
		this.endDate = endDate;
		
		var numberOfDays = this.startDate.diff(this.endDate);
		
		for(var i = 0; i < numberOfDays; i++) {
			this.days.push(false);
		}
		
		this.addDay(dayData);
	}
	
	addDay(dayData){
		var day = this.startDate.diff(new Date().parse(dayData.date));
		this.days[day] = dayData;
	}
	
}
require('../js/MooTools-Core-1.2.6.js');
const { ipcRenderer } = require('electron')
var parkinfo = require('../js/campsites.js');

document.addEventListener('DOMContentLoaded', function () {
	/*
	var timeScrubTestButton = new Element('button', {id: "timeScrubTest", html: 'test time scrub'})
	
	timeScrubTestButton.inject(document.body);
	var goToSiteTestSelect = new Element('select', {id: "goToSiteTest", html: 'test go to site'}).inject(document.body);
	
	timeScrubTestButton.addEvent('click', function(){
		var startDate = new Date().parse("03/12/2018");
		var endDate = new Date().parse("04/12/2018");
		
		reportBackAvailabilityForDateRange(startDate, endDate);
	}.bind(this))
	
	
	goToSiteTestSelect.addEvent('change', function(e){
		var selected = e.target.options[e.target.selectedIndex];
		tabMessage("tellMeToLoadSite", {place_id:selected.value, facilityid:selected.get('name')});
		
		goToSite(selected.value, selected.get('name'));
		
	}.bind(this))
	
	new Element('option', {value: -1, html: "-- Jump to Campsite --"}).inject(goToSiteTestSelect);
	
	for(var campSite of parkinfo){
		new Element('option', {value: -1, html: "--"+campSite.clean_name+"--"}).inject(goToSiteTestSelect);
		
		for(var facility of campSite.facilities){
			new Element('option', {value: campSite.place_id, name: facility.id, html: facility.name}).inject(goToSiteTestSelect);
		}
	}
	*/
	
	tabMessage("whereShouldIBe",{});
	checkForErrorBox.periodical(1000); //start checking for errors
});

var foundError = false;


ipcRenderer.on('searchDateRange', function(event, data){
	console.log('msg:searchDateRange');
	//scrub page for availability in that date range
	if(document.id('liFacilityName')){
		if(document.id('liFacilityName').get('html') != ''){
			var startDate = new Date(Date.parse(data.startDate));
			var endDate = new Date(Date.parse(data.endDate));
			
			//console.log('reportBackAvailabilityForDateRange');
			reportBackAvailabilityForDateRange(startDate, endDate);
			
		}else{
			console.log('we simply are not ready for this 1');
		}
	}else{
		console.log('we simply are not ready for this 2');
	}
});


ipcRenderer.on('goToSite', function(event, data){
	console.log('msg:goToSite');
	goToSite(data.place_id, data.facilityid);
});
	
ipcRenderer.on('youShouldBeHere', function(event, data){
	console.log('msg:youShouldBeHere');
	checkIfWeAreWhereWeShouldBe(data.place_id, data.facilityid, data.parkName, data.facilityName, data.startDate);
});
	
ipcRenderer.on('setTheDate', function(event, data){
	console.log('msg:setTheDate');
	var date = new Date(Date.parse(data.startDate));
	setDate(date);
});

function checkForErrorBox(){
	if(foundError) return;
	
	var error = false;
	
	if(document.id('messageBoxLightbox1')){
		if(document.id('messageBoxLightbox1').getStyle('display') != 'none'){
		
			if(document.id('mainContent_mbNotice_hiddnemsg')){
				foundError = true;
				error = document.id('mainContent_mbNotice_hiddnemsg');
			}
			
			if(document.id('ctl00_mbNotice_hiddnemsg')){
				foundError = true;
				error = document.id('ctl00_mbNotice_hiddnemsg');
			}
		}
	}
	
	if(error) tabMessage("tabHasAnError",{error: error.value});
}

function reportBackAvailabilityForDateRange(startDate, endDate){
//this sets the date range and then scrubs the table for availability
	console.log('reportBackAvailabilityForDateRange');
	
	setDate(startDate, function(){
		tabMessage("searchUpdate",{daysLeft: dayDiff(startDate, endDate)});
		scrubTimeTable();
		
		incrementDateByDays(startDate , 21);
		
		if(dayDiff(startDate, endDate) > 0){
			console.log('we need to go again', dayDiff(startDate, endDate), startDate, endDate);
			reportBackAvailabilityForDateRange.delay(500, this, [startDate, endDate]);
		}else {
			console.log("we are done");
			tabMessage("searchComplete",{});
		}
		
	}); 
}

function scrubTimeTable(){
	var dayObjects = [];
	
	var tableRows = document.id("divUnitGridlist").getElement('table').getElements('tr');
	
	Array.each(tableRows, function(tableRow, index){
	  var dayElements = tableRow.getElements('td');
	  var handicap = false;
	  var hasAvailability = tableRow.getElement('.blue_brd_box');
	  
	  var firstRow = tableRow.getElement('.first_td_new');
	  
	  if(firstRow){	
	  	if(firstRow.getElement('.hendi_icn')){
	  		console.log('handicap - Skipping');
	  		handicap = true;
	  	}
	  } 
	  
	  if(!handicap && hasAvailability){	
	  	console.log('dayElements', dayElements.length);
		Array.each(dayElements, function(dayElement, index){
			if(!dayElement.hasClass('first_td_new')){
				var onclickValue = dayElement.get('onclick');
				
				var dayObject;
				
				try {
					if(onclickValue.substring(0, 7) == 'return '){
						onclickValue = onclickValue.substring(7);
					}else{
						console.log('onclickValue.substring(0, 7)', onclickValue.substring(0, 7));
					}
					
					dayObject = eval(onclickValue); //should run it through showPopWindowAdvanceSearch
				}catch (error) {
					console.log('error', error);
				}
				
				
				if(dayObject){
					dayObjects.push(dayObject);
					tabMessage("unitDayInformation",dayObject);
					//console.log('it worked here');
				}else{
					console.log('it did not work here');
				}
			}
		});
	  }
	});

	return dayObjects; //only here if we want to print them out easily - For debugging
}

var pad = function(what, length){
	return new Array(length - String(what).length + 1).join('0') + what;
};

function dayDiff(startDate, endDate){
	return ((endDate - startDate) / 86400000).toInt();
}

function incrementDateByDays(date, days){
	date.setDate(date.getDate() + days);
}

function formatDate(d){
	var m =  pad((d.getMonth() + 1), 2)
	var d2 = pad(d.getDate(), 2);
	var Y = d.getFullYear();
	
	return m+'/'+d2+'/'+Y;
}

//DO NOT CHANGE THIS. IT IS PARTIAL STOLEN CODE FROM THE SITE AND IT IS EXPECTING IT
//this scrubs a table cell link to see if it is available
function showPopWindowAdvanceSearch(e, url, iconid, date, column, row){
	//must be named this - "showPopWindowAdvanceSearch" is called from the eval function above. We just use this to pull apart the input that was normall sent to it
	var getParams = url.substring(21);
	var paramObject = JSON.parse('{"' + decodeURI(getParams).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g,'":"') + '"}')
	
	var available = (paramObject.is_available === 'true');
	
	var campObject = {
		date: formatDate(new Date(Date.parse(date))),
		unit_id: parseInt(paramObject.unit_id),
		facility_id: parseInt(paramObject.facility_id),
		is_available: available
	};
	
	return campObject;
}

//I don't understand why this ever gets called. DO NOT REMOVE IT IS TO DEAL WITH A BUG - called from EVAL
function bAvailabilityCell_click(column, row) {
	return false;
}


function goToSite(place_id, facilityid, callback){
	console.log('am called');
	//go to the proper park, it's a 2 parter
	ContainFacilityClick_mapbox2(place_id,'Medium');
	
	//wait half a second and set the facilityid (the 2nd part)
	ViewReservedirectFacilityLevel2.delay(500, this, [facilityid, place_id, 'Campgrounds', 1]);
}


function setDate(date, callback){
//setting date requires two commands on the client side. Then we wait to make sure it actually happened
	
	var header = document.getElement('#mainContent_ugReservationGrid_tableGridParent .one_new_table thead .date_value th');
	
	console.log('setDate', date, header);
	
	if(!header){
		if(document.id('mainContent_ugReservationGrid_tableGridParent').get('html') == "Object reference not set to an instance of an object."){
			tabMessage("tabHasAnError",{error: "Object reference not set to an instance of an object."});
		}
	}
	
	var headerDate = header.get('title')	;
	var headerDateObj = new Date(headerDate);
	var timeWaitedForTableLoad = 0;	
	
	if(formatDate(headerDateObj) == formatDate(date)){
		console.log('Oh cool! We are already there');
		if(checkTableLoadedTimer) clearInterval(checkTableLoadedTimer);
		if(callback) callback.delay(1000, this)
		
		return;
	}
	
	
	var dateStr = formatDate(date);
	injectViaIMG('updategrid("'+dateStr+'")');	
	injectViaIMG.delay(250, this, ['getUnitgridPopupNights()']);

	var checkTableLoadedTimer;
	
	function setDate_checkIfTableLoaded(){
		if(!document.id('divUnitGridlist')) return false;	
		if(document.id("divUnitGridlist").getElement('table').getElements('td').length < 42) return false;
		
		if(!document.id('divUnit_loder')) return false;
		if(document.id('divUnit_loder').getStyle('display') == 'none') return true;
		
		return false;
	}
	
	function setDate_checkTableLoaded(){
		
		if(timeWaitedForTableLoad > 40){
			console.log('Taking forever! Lets try again');
			if(checkTableLoadedTimer) clearInterval(checkTableLoadedTimer);
			setDate(date, callback)
		}
		
		if(setDate_checkIfTableLoaded()){
			var header = document.getElement('#mainContent_ugReservationGrid_tableGridParent .one_new_table thead .date_value th');
			
			if(!header){
				if(document.id('mainContent_ugReservationGrid_tableGridParent').get('html') == "Object reference not set to an instance of an object."){
					tabMessage("tabHasAnError",{error: "Object reference not set to an instance of an object."});
				}
			}else{
				var headerDate = header.get('title')
				var headerDateObj = new Date(headerDate);
				
				if(formatDate(headerDateObj) == formatDate(date)){
					console.log('the table is loaded, we can move on');
					if(checkTableLoadedTimer) clearInterval(checkTableLoadedTimer);
					if(callback) callback.delay(1000, this)
				}else{
					console.log('table isnt actually loaded yet', formatDate(headerDateObj), formatDate(date));
					timeWaitedForTableLoad ++;
				}
			}
		}else{
			console.log('table isnt loaded yet');
			timeWaitedForTableLoad ++;
		}
	}
	
	(function(){
		checkTableLoadedTimer = setDate_checkTableLoaded.periodical(250, this); //start a timer checking if the 
	}).delay(300, this)
}

function ViewReservedirectFacilityLevel2(facilityid, place_id, category, facilitytype){	
//part of how we select the park and campsite on the client.	
	injectViaIMG('ViewReservedirectFacilityLevel('+facilityid+', '+place_id+', "'+category+'", '+facilitytype+')');
}

function ContainFacilityClick_mapbox2(place_id, Parksize){
//part of how we select the park and campsite on the client.
	injectViaIMG("ContainFacilityClick_mapbox("+place_id+",'"+Parksize+"')");
}

function injectViaIMG(codeStr){
//inject the code on the client side using a 1x1px image as our trojen horse. HAHAHAHAHAHAHAAHA	
	var myImage = new Image();
	myImage.onload = myImage.onload = eval(codeStr);
	myImage.src = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
	document.body.appendChild(myImage);
}



//wait 2 seconds and then check to make sure we are on a search result page. If not, get there
//report to global when we are on the search result page

function checkIfWeAreWhereWeShouldBe(place_id, facilityid, correctPlaceName, correctFacilityName, startDate){
	console.log('checkIfWeAreWhereWeShouldBe');
	
	
	correctFacilityName = correctFacilityName.replace(/\s\s+/g, ' ');
	correctPlaceName = correctPlaceName.replace(/\s\s+/g, ' ');
	
	
	if(document.id("mainContent_txtArrivalDate")){
		//on the main page. Do a BS search to get to the right page
		tabMessage("onMainPage",{});
		document.id("mainContent_txtArrivalDate").value = formatDate(new Date(startDate));
		document.id("ddlHomeNights").value = 1;
		injectViaIMG("validation()");
	}else if(document.id("PlName")){
		var placeName = document.id('PlName').get('html');
		var facilityName = document.id('liFacilityName').get('html');
		
		facilityName = facilityName.replace(/&amp;/g, '&');
		placeName = placeName.replace(/&amp;/g, '&');
		
		
		facilityName = facilityName.replace(/\s\s+/g, ' ');
		placeName = placeName.replace(/\s\s+/g, ' ');
		
		
		if(correctPlaceName == placeName && correctFacilityName == facilityName){
			console.log('in the right place!');
			tabMessage("inTheRightPlace",{});
			tabMessage("searchUpdate",{daysLeft: -1});
		}else{
			tabMessage("inTheWrongPlace",{
				'correctPlaceName': correctPlaceName,
				'placeName': placeName,
				'correctFacilityName': correctFacilityName,
				'facilityName': facilityName,
			});
			console.log('in the wrong place!', 'sb:'+correctPlaceName, 'is:'+placeName, 'sb:'+correctFacilityName, 'is'+facilityName);
			goToSite(place_id, facilityid);
			tabMessage("searchUpdate",{daysLeft: -2});
		}
		
	}
}

function tabMessage(name, message){
	ipcRenderer.send('tabMessage', {name: name, message: message})
}
var SiteBookingWrapper = new Class({
	
	initialize: function(wrapper, titleWrapper, siteInfo){		
		this.wrapper = document.id(wrapper);
		//this.titleWrapper = document.id(titleWrapper);
		this.body = new Element('div', {'class': 'siteBookingWrapper'}).inject(this.wrapper);
		this.title = new Element('h1', {html: siteInfo.clean_name}).inject(this.body);
		this.facilityDiv = new Element('div', {'class': 'facilities'}).inject(this.body);
		
		
		//var position = this.body.getPosition(this.wrapper);
		//console.log(position);
		
		
		//this.title.setStyle('top', position.y);
	}
});


var SiteBooking = new Class({
	Implements: [Events],
	
	initialize: function(wrapper, siteInfo, facility, startdate, lengthOfStay){		
		this.wrapper = document.id(wrapper);
		
		this.body = new Element('div', {'class': 'siteBooking'}).inject(this.wrapper);
		if(facility.type == 'Cabins-Other Lodging') this.body.addClass('cabin');
		if(facility.type == 'Campgrounds') this.body.addClass('camping');
		if(facility.type == 'Group Camping') this.body.addClass('group');
		
		this.title = new Element('h2', {html: facility.name}).inject(this.body);
		if(facility.type == 'Cabins-Other Lodging') this.title.addClass('cabin');
		if(facility.type == 'Campgrounds') this.title.addClass('camping');
		if(facility.type == 'Group Camping') this.title.addClass('group');
		
		
		this.progressBarWrapper = new Element('div', {"class": "progressBarWraper"}).inject(this.body);
		this.progressBar = new Element('div', {"class": "progressBar"}).inject(this.progressBarWrapper);
		
		this.spots = [];
		this.lengthOfStay = lengthOfStay;
		this.name = siteInfo.name;
		this.info = siteInfo;
		this.facility = facility;
		this.cleanName = siteInfo.clean_name;
		
		for(var i = 0; i < lengthOfStay; i++){
			var width = 100/lengthOfStay;
			var dayMarker = new Element('span', {'class': 'dayMarker'}).inject(this.body).setStyle('width', width+'%');
		}
		
		this.spotsDiv = new Element('div', {'class': 'spots'}).inject(this.body);
	},
	
	updateProgress: function(percent){
		console.log(this.facility.name+': '+percent);
		this.progressBar.setStyle('width', percent+"%");
	},
	
	searchStarted: function(){
		console.log("search started on: "+this.facility.name);
		this.progressBarWrapper.setStyle('display', 'block');
	},
	
	searchComplete: function(){
		console.log("search complete on: "+this.facility.name);
		this.progressBarWrapper.setStyle('display', 'none');
	},
	
	addSpot: function(spotInfo){
		
		
		var campSpot = new CampSpot(this.spotsDiv, spotInfo, this.lengthOfStay);
		//console.log('spotInfo', spotInfo);
		campSpot.addEvent('openReservationTab', function(e){
				this.fireEvent('openReservationTab', e);
		}.bind(this));
		
		if(this.spots.length > 0){
			var lastSpot = this.spots[this.spots.length - 1];
			
			if(lastSpot.body.hasClass('available')){
				if(campSpot.body.hasClass('notAvailable')){
					campSpot.body.addClass('first');
				}
			}else{
				if(campSpot.body.hasClass('notAvailable')){
					lastSpot.body.addClass('chain');
					lastSpot.body.removeClass('last');
					
					campSpot.body.addClass('chain');
					campSpot.body.addClass('last');
				}
			}
			
		}else {
			if(campSpot.body.hasClass('notAvailable')){
				campSpot.body.addClass('first');
			}
		}
		
		this.spots.push(campSpot);
	}
});

var CampSpot = new Class({
	Implements: [Events],
	
	initialize: function(wrapper, dayInfo, lengthOfStay){
		this.wrapper = document.id(wrapper);
		
		this.place_id = dayInfo.place_id;
		this.facilityid = dayInfo.facilityid;
		this.startDate = new Date().parse(dayInfo.siteInfo.date);
		this.lengthOfStay = lengthOfStay;
		
		dayInfo.url = 'test.html'; //just for now
		
		//console.log('dayInfo', dayInfo);
		
		this.dayElements = [];
		
		if(dayInfo.siteInfo.siteID != -1){
			
			this.body = new Element('span', {'class': 'available spot'}).inject(this.wrapper);
			var width = 100/this.lengthOfStay * dayInfo.siteInfo.days;
			this.body.setStyle('width', width+'%')
			
			for(var i = 0; i < dayInfo.siteInfo.days; i++){
				
				var dayDate = new Date(this.startDate);
				if(i > 0) dayDate.increment('day', i);
				
				var dayElement = new Element('a', {href: dayInfo.url, date: dayDate.format('%x')}).inject(this.body);
				var width = 100/dayInfo.siteInfo.days;
				dayElement.setStyle('width', width+'%')
				
				dayElement.addEvent('click', function(e){
					e.stop();
					this.fireEvent('openReservationTab', {
						place_id: this.place_id,
						facilityid: this.facilityid,
						date: e.target.get('date')
					});
				}.bind(this));
				
				this.dayElements.push(dayElement);
				
				dayElement.addClass(dayDate.format('%a'));
				if(i == 0) dayElement.addClass('first');
				if(i == dayInfo.siteInfo.days - 1) dayElement.addClass('last');
			}
			
			
			
		}else{
			var width = 100/this.lengthOfStay;
			this.body = new Element('span', {'class': 'notAvailable spot'}).inject(this.wrapper);
			this.body.setStyle('width', width+'%')
			//console.log('width', width+'%');
		}	
	}
});

var CampSite = new Class({
	Implements: [Events],
	
	initialize: function(wrapper, siteInfo, mapMarker){
		this.wrapper = document.id(wrapper);
		this.info = siteInfo;
		this.name = siteInfo.name;
		this.body = new Element('div', {'class': 'campSite'}).inject(this.wrapper);	
		
		this.body.addEvent('mouseenter', function(){
			if(!this.hovering) this.fireEvent('hover',this);
		}.bind(this));
		
		this.body.addEvent('mouseleave', function(){
			if(!this.hovering) this.fireEvent('endHover',this);
		}.bind(this));
		
		this.checkBox = new Element('input', {type: 'checkbox', value: this.info.name, id: this.info.name}).inject(this.body);
		this.mapMarker = mapMarker;
		
		//var link = '<a href="http://www.'+this.info.site+'/camping/r/campgroundDetails.do?contractCode='+this.info.contractCode+'&parkId='+this.info.parkId+'" target="void">'+this.info.clean_name+'</a>';
		var link = '<a>'+this.info.clean_name+'</a>';
		
		//var label = new Element('label', {for: this.info.name, html: link}).inject(this.body);
		
		var label = new Element('h3', {for: this.info.name, html: this.info.clean_name}).inject(this.body);
		
		label.addEvent('click', function(){
			this.fireEvent('labelClicked', this);
		}.bind(this));
		
		var amenitiesDiv = new Element('div', {'class': 'amenities'}).inject(this.body);
		
		new Element('div', {'class': 'maxPeople', html: this.info.max_people}).inject(this.body);
		new Element('div', {'class': 'maxCars', html: this.info.max_vehicles}).inject(this.body);
		
		for (var amenity in siteInfo.amenities) {
			var available = (siteInfo.amenities[amenity])? 'available': 'notAvailable';
		  
			new Element('span', {'class': 'amenity '+amenity+' '+available}).inject(amenitiesDiv);
		}
		
	},
	
	selected: function(){
		return this.checkBox.checked
	}
});


var checkBox = new Class({
	
	initialize: function(wrapper){
		this.checked = false;
		this.body = new Element('div', {'class': 'customCheckBox'}).inject(document.id(wrapper));
		
		this.body.addEvent('click', this.toggle.bind(this));
	},
	
	toggle: function(){
		this.checked = !this.checked;
		
		if(this.checked){
			this.body.addClass('checked');
		}else{
			this.body.removeClass('checked');
		}
	}
});


